<footer class="light-footer skin-light-footer style-2">
	<div class="footer-bottom br-top">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-12 col-md-12 text-center align-items-center">
					<p class="mb-0">© <?php echo date("Y"); ?> SaharDirectory. Designd By <a href="http://webangeltech.com/" target="_blank" style="color: #20aaff;"> <img src="assets/img/webangeltech.png" width="20px" alt=""> Webangeltech.</a></p>
				</div>
			</div>
		</div>
	</div>
</footer>