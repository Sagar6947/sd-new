<?php
if (mysqli_num_rows($contact) > 0) {
    echo 'This Contact no. is already registered';
}

