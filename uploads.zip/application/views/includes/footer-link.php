	<!-- ============================================================== -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/slick.js"></script>
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="../assets/js/dropzone.js"></script>
	<script src="assets/js/counterup.js"></script>
	<script src="assets/js/lightbox.js"></script>
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/daterangepicker.js"></script>
	<script src="assets/js/lightbox.js"></script>
	<script src="assets/js/jQuery.style.switcher.js"></script>
	<script src="assets/js/custom.js"></script>


	<!-- Morris.js charts -->
	<script src="assets/js/plugins/raphael/raphael.min.js"></script>
	<script src="assets/js/plugins/morris.js/morris.min.js"></script>

	<!-- Custom Chart JavaScript -->
	<script src="assets/js/plugins/dashboard-2.js"></script>
	<!-- ============================================================== -->
	<!-- This page plugins -->
	<!-- ============================================================== -->


<script>
     window.setTimeout(function() {
         $(".alert").fadeTo(200, 0).slideUp(200, function() {
             $(this).remove();
         });
     }, 4000);


		if (window.history.replaceState) {
			window.history.replaceState(null, null, window.location.href);
		}
	</script>

	</body>


	</html>