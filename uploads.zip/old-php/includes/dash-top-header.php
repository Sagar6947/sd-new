<section class="bg-cover position-relative" style="background:red url(assets/img/cover.jpg) no-repeat;" data-overlay="3">
			<div class="abs-list-sec right_pos"><a href="" class="add-list-btn"><i class="fas fa-id-card me-2"></i>Visit your vcard/website</a></div>
			<div class="abs-list-sec"><a href="dashboard-add-listing.php" class="add-list-btn"><i class="fas fa-plus me-2"></i>Add Product</a></div>
			<div class="container">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

						<div class="dashboard-head-author-clicl">
							<div class="dashboard-head-author-thumb">
								<img src="assets/img/t-7.png" class="img-fluid" alt="" />
							</div>
							<div class="dashboard-head-author-caption">
								<div class="dashploio">
									<h4>Charles D. Robinson</h4>
								</div>
								<div class="dashploio"><span class="agd-location"><i class="lni lni-map-marker me-1"></i>San Francisco, USA</span></div>
								<div class="listing-rating high"><i class="fas fa-star active"></i><i class="fas fa-star active"></i><i class="fas fa-star active"></i><i class="fas fa-star active"></i><i class="fas fa-star active"></i></div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</section>